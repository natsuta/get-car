<footer>
    
	<div class="footer">
		<a href="index.php">Home</a>
		<a href="menu.php">About Us</a>
		<a href="order.php">How to Use</a>
		<a href="cart.php">Pricing</a>
		<a href="queue.php">Locations and Cars</a>
		</a>
		<br>
		<p>GetCar 2019 ©</p>
	</div>
	
</footer>
</html>