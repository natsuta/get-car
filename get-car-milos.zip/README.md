# car-share
For Capstone Project Semester 2 2019

Team members:
Sherman Wong s3656264
Lei Guo s3516439
Yong Xing Zhang s3604253
Milos Mladenovic s3656006

## Release 1 - 22 August 2019
- Home page
- Registration and login pages
- Car and customer data pages drafted