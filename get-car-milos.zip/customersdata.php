
<html>
 <head>
  <title>Getcar customer database</title>
 </head>
 <body>
<h2>Customers Database</h2>
 <p>Establishing a connection to an customers database.</p><p>Successfully connected to CSAMPR1.ITS.RMIT.EDU.AU.</p>Current System Date in Oracle Database is 22/AUG/19<br>
<table border='1'>
<tr><td><B>FIRSTNAME (VARCHAR2)</B></td><td><B>LASTNAME (VARCHAR2)</B></td><td><B>MOBILE (VARCHAR2)</B></td><td><B>EMAIL (VARCHAR2)</B></td></tr>
<tr>
    <td>John</td>
    <td>Piper</td>
    <td>0455566666</td>
    <td>321@gmail.com</td>
</tr>
<tr>
    <td>Benjamin</td>
    <td>Wikins</td>
    <td>0477788888</td>
    <td>5628@gmail.com</td>
</tr>
<tr>
    <td>David</td>
    <td>Smith</td>
    <td>0456284691</td>
    <td>89797@gmail.com</td>
</tr>
<tr>
    <td>Conor</td>
    <td>White</td>
    <td>0469898456</td>
    <td>conor@gmail.com</td>
</tr>
<tr>
    <td>Vanessa</td>
    <td>Vaughan</td>
    <td>0467995123
</td>
    <td>vanessa@gmail.com</td>
</tr>
<tr>
    <td>Kevin </td>
    <td>Stinger</td>
    <td>0466612489</td>
    <td>kevin@gmail.com</td>
</tr>
<tr>
    <td>Vincent</td>
    <td>Gogh</td>
    <td>0466112489</td>
    <td>vincent@gmail.com</td>
</tr>
</table>

 </body>
</html>