
<html>
 <head>
  <title>Getcar customer database</title>
 </head>
 <body>
<h2>Rental cars Database</h2>
 <p>Establishing a connection to an rental cars database.</p><p>Successfully connected to CSAMPR1.ITS.RMIT.EDU.AU.</p>Current System Date in Oracle Database is 22/AUG/19<br>
<table border='1'>
<tr><td><B>LICENSEPLATE (VARCHAR2)</B></td><td><B>BRAND (VARCHAR2)</B></td><td><B>TYPE (VARCHAR2)</B></td><td><B>COLOUR (VARCHAR2)</B></td><td><B>LOCATION (VARCHAR2)</B></td><td><B>STATUS (CHAR)</B></td><td><B>CUSTOMER_ID (VARCHAR2)</B></td><td><B>LAST_NAME (VARCHAR2)</B></td></tr>
<tr>
    <td>8BJEOH</td>
    <td>MAZDA</td>
    <td>SEDAN</td>
    <td>BLACK</td>
    <td>FOOTSCRAY</td>
    <td>AVAILAIBLE          </td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
</tr>
<tr>
    <td>9UHBRH</td>
    <td>TOYOTA</td>
    <td>SUV</td>
    <td>RED</td>
    <td>SUNBURY</td>
    <td>AVAILABLE           </td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
</tr>
<tr>
    <td>HUY7JH</td>
    <td>HOLDEN</td>
    <td>WAGON</td>
    <td>BLUE</td>
    <td>EPPING</td>
    <td>IN-USE              </td>
    <td>2</td>
    <td>Wilkins</td>
</tr>
<tr>
    <td>NH9GHI</td>
    <td>FORD</td>
    <td>HATCH-BACK</td>
    <td>WHITE</td>
    <td>ESSENDON</td>
    <td>IN-USE              </td>
    <td>1</td>
    <td>Piper</td>
</tr>
<tr>
    <td>JKU9HG</td>
    <td>BMW</td>
    <td>SEDAN</td>
    <td>BLACK</td>
    <td>DEERPARK</td>
    <td>IN-USE              </td>
    <td>4</td>
    <td>White</td>
</tr>
</table>

 </body>
</html>